public class Patient extends Person {
    private Doctor patientDoctor;

    public Patient() {
        this("No name", new Doctor());
    }
    public Patient(String name, Doctor patientDoctor) {
        super(name);
        setPatientDoctor(patientDoctor);
    }
    public Patient(Patient other) {
        this(other.getName(), other.getPatientDoctor());
    }

    //Getters and Setters
    public Doctor getPatientDoctor() {
        return patientDoctor;
    }
    public void setPatientDoctor(Doctor patientDoctor) {
        this.patientDoctor = patientDoctor;
    }

    //Methods
    public String toString() {
        return "The name is: " + getName() + ", Primary doctor is: " + getPatientDoctor().getName();
    }
    public boolean equals(Patient other) {
        return (super.equals(other) && (getPatientDoctor().equals(other.getPatientDoctor())));
    }
}
