public class SalariedEmployee extends Employee {
    private double salary;

    public SalariedEmployee() {
        this("No name", new Date(), 0.1);
    }
    public SalariedEmployee(String name, Date hiringDate, double salary) {
        super(name, hiringDate);
        setSalary(salary);
    }
    public SalariedEmployee(SalariedEmployee other) {
        this(other.getName(), other.getHiringDate(), other.getSalary());
    }

    //Getters and Setters
    public double getSalary() {
        return salary;
    }
    public void setSalary(double salary) {
        if (salary < 0.0) {
            System.out.println("Salary cannot be negative.");
            System.exit(0);
        }
        this.salary = salary;
    }

    //Methods
    public String toString() {
        return super.toString() + " and has a salary of $" + getSalary();
    }
    public boolean equals(SalariedEmployee other) {
        return (super.equals(other) && getSalary() == other.getSalary());
    }
}
