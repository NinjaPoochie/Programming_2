public class Billing {
    private Patient aPatient;
    private Doctor aDoctor;
    private double amountDue;

    public Billing() {
        this(new Patient(), new Doctor(), 0.0);
    }
    public Billing(Patient aPatient, Doctor aDoctor, double amountDue) {
        setADoctor(aDoctor);
        setAPatient(aPatient);
        setAmountDue(amountDue);
    }
    public Billing(Billing other) {
        this(other.aPatient,other.aDoctor,other.amountDue);
    }

    //Getters and Setters
    public Patient getAPatient() {
        return aPatient;
    }
    public void setAPatient(Patient aPatient) {
        this.aPatient = aPatient;
    }
    public Doctor getADoctor() {
        return aDoctor;
    }
    public void setADoctor(Doctor aDoctor) {
        this.aDoctor = aDoctor;
    }
    public double getAmountDue() {
        return amountDue;
    }
    public void setAmountDue(double amountDue) {
        if (amountDue < 0.0) {
            System.out.println("Amount due cannot be negative.");
            System.exit(0);
        }
        this.amountDue = amountDue;
    }

    //Methods
    public String toString() {
        return "\nPatient: " + getAPatient().getName() + "\nDoctor: " + getADoctor().getName() + "\nAmount due: $" + getAmountDue();
    }
    public boolean equals(Billing other) {
        return (getAPatient().equals(other) && (getADoctor().equals(other)) && (getAmountDue() == other.getAmountDue()));
    }
}
