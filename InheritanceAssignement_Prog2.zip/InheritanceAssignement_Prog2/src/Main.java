public class Main {
    public static void main(String[] args) {
        Doctor d1 = new Doctor("Bob", new Date(12,31,1969),34000.0,"Pediatrician",10.5);
        System.out.println(d1);
        Doctor d2 = new Doctor("Susan", new Date(12,31,1969),450000.0,"Surgeon",150.5);
        System.out.println(d2);
        Doctor d3 = new Doctor("Lilly", new Date(12,31,1969),290000.0,"Kidney",95.9);
        System.out.println(d3);

        System.out.println("\n*Patient's Information*");
        Patient p1 = new Patient("Fred", d1);
        System.out.println(p1);
        Patient p2 = new Patient("Sally", d2);
        System.out.println(p2);
        Patient p3 = new Patient("John", d3);
        System.out.println(p3);

        System.out.println("\n*Billing's Information*");
        Billing b1 = new Billing(p1,d1,21.0);
        System.out.println(b1);
        Billing b2 = new Billing(p2,d2,150.5);
        System.out.println(b2);
        Billing b3 = new Billing(p3,d3,170.0);
        System.out.println(b3);

        double total = b1.getAmountDue() + b2.getAmountDue() + b3.getAmountDue();
        System.out.println("The total income from billing records is: $" + total);
    }
}
