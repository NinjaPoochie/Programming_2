public class Employee extends Person {
    private Date hiringDate;

    public Employee() {
        this("No name", new Date());
    }
    public Employee(String name, Date hiringDate) {
        super(name);
        setHiringDate(hiringDate);
    }
    public Employee(Employee other) {
        this(other.getName(), other.hiringDate);
    }

    //Getters and Setters
    public Date getHiringDate() {
        return hiringDate;
    }
    public void setHiringDate(Date hiringDate) {
        if (hiringDate == null) {
            System.out.println("Invalid hiring date.");
            System.exit(0);
        }
        this.hiringDate = hiringDate;
    }

    //Methods
    public String toString() {
        return super.toString() + " was hired on " + getHiringDate();
    }
    public boolean equals(Employee other) {
        return super.equals(other) && getHiringDate().equals(other.getHiringDate());
    }
}
