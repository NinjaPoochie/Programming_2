public class Person {
    private String name;

    public Person() {
        this("No name yet");
    }
    public Person(String name) {
        setName(name);
    }
    public Person(Person other) {
        this(other.name);
    }

    //Getters and Setters
    public String getName() {
        return name;
    }
    public void setName(String name) {
        if (name == null) {
            System.out.println("Invalid employee name.");
            System.exit(0);
        }
        this.name = name;
    }

    //Methods
    public String toString() {
        return name;
    }
    public boolean equals(Person other) {
        return (getName().equals(other.getName()));
    }
}
