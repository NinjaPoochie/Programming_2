public class Doctor extends SalariedEmployee {
    private String specialty;
    private double visitFee;

    public Doctor() {
        this("No name", new Date(), 0.1, "None", 0.1);
    }
    public Doctor(String name, Date hiringDate, double salary, String specialty, double visitFee) {
        super(name, hiringDate, salary);
        setSpecialty(specialty);
        setVisitFee(visitFee);
    }
    public Doctor(Doctor other) {
        this(other.getName(), other.getHiringDate(), other.getSalary(), other.getSpecialty(), other.getVisitFee());
    }

    //Getters and Setters
    public String getSpecialty() {
        return specialty;
    }
    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }
    public double getVisitFee() {
        return visitFee;
    }
    public void setVisitFee(double visitFee) {
        if (visitFee < 0.0) {
            System.out.println("Visit fee cannot be negative.");
            System.exit(0);
        }
        this.visitFee = visitFee;
    }

    //Methods
    public String toString() {
        return (super.toString() + "\nThe specialty is " + getSpecialty() + " and visit fee is $" + getVisitFee());
    }
    public boolean equals(Doctor other) {
        return (super.equals(other) && (getSpecialty().equals(other.getSpecialty())) && (getVisitFee() == other.getVisitFee()));
    }
}
