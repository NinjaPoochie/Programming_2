public class Employee {
    private String employeeID;
    private String name;
    private String department;
    private double salary;
    private String designation;

    public Employee() {
        this("No ID", "No name", "No department", 0.0, "No designation");
    }
    public Employee(String employeeID, String name, String department, double salary, String designation) {
        setEmployeeID(employeeID);
        setName(name);
        setDepartment(department);
        setSalary(salary);
        setDesignation(designation);
    }
    public Employee(Employee other) {
        this(other.employeeID, other.name, other.department, other.salary, other.designation);
    }

    //Setters and Getters

    public String getEmployeeID() {
        return employeeID;
    }
    public void setEmployeeID(String employeeID) {
        this.employeeID = employeeID;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getDepartment() {
        return department;
    }
    public void setDepartment(String department) {
        this.department = department;
    }
    public double getSalary() {
        return salary;
    }
    public void setSalary(double salary) {
        this.salary = salary;
    }
    public String getDesignation() {
        return designation;
    }
    public void setDesignation(String designation) {
        this.designation = designation;
    }

    //Methods
    public String toString() {
        return "Employee ID: " + getEmployeeID() + "\nEmployee name: " + getName() + "\nDepartment Name: " + getDepartment() +
                "\nSalary: " + getSalary() + "\nDesignation: " + getDesignation();
    }
    public boolean equals(Employee other) {
        return (getEmployeeID().equals(other.getEmployeeID()) && getName().equals(other.getName()) && (getDepartment().equals(other.getDepartment())
        && (getSalary() == other.getSalary()) && (getDesignation().equals(other.getDesignation()))));
    }
    public double calcDeductions(int daysPresent) {
        return getSalary() * ((20 - daysPresent) / 20.0);
    }
}
