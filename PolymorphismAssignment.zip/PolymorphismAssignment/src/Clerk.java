public class Clerk extends Employee {
    private double bonus;

    public Clerk() {
        this("No ID", "No name", "No department", 0.0, "No designation", 100.0);
    }
    public Clerk(String employeeID, String name, String department, double salary, String designation, double bonus) {
        super(employeeID, name, department, salary, designation);
        setBonus(bonus);
    }
    public Clerk(Clerk other) {
        this(other.getEmployeeID(), other.getName(), other.getDepartment(), other.getSalary(), other.getDesignation(), other.getBonus());
    }

    //Setters and getters
    public double getBonus() {
        return bonus;
    }
    public void setBonus(double bonus) {
        this.bonus = bonus;
    }

    public double addBonus() {
        return getSalary() + 100;
    }
    public String toString() {
        return super.toString() + "\nSalary after adding bonus is: " + addBonus();
    }
    boolean equals(Clerk other) {
        return (super.equals(other)) && addBonus() == other.addBonus();
    }
    public double calcDeductions(int daysPresent) {
        return addBonus() * ((20 - daysPresent) / 20.0);
    }
}
