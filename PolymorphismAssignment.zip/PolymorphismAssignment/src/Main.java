import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Manager m1 = new Manager("E001", "Mark", "HR", 15000.0, "Manager", 300);
        System.out.println(m1);
        System.out.println();

        Manager m2 = new Manager("E012", "Peter", "R&D", 15000, "Manager", 300);
        System.out.println(m2);
        System.out.println();

        Clerk c1 = new Clerk("E056", "Samuel", "Accounts", 10000, "Clerk", 100);
        System.out.println(c1);
        System.out.println();

        Clerk c2 = new Clerk("E089", "Jake", "Accounts", 10000, "R&D", 100);

        if (m1.equals(c1)) {
            System.out.println(m1.getName() + " and " + c1.getName() + " have the same designations.");
        } else {
            System.out.println(m1.getName() + " and " + c1.getName() + " have different designations.");
        }

        Scanner keyboard = new Scanner(System.in);
        int userInput;

        Employee[] arr = new Employee[4];
        int[] daysPresent = new int[4];

        arr[0] = m1;
        arr[1] = m2;
        arr[2] = c1;
        arr[3] = c2;

        System.out.println();
        for (int i = 0; i < arr.length; i++) {
            System.out.println("Enter the number of days Employee " + arr[i].getEmployeeID() + " is Present out of 20: ");
            userInput = keyboard.nextInt();
            daysPresent[i] = userInput;
        }

        print(arr, daysPresent);


        /**
        print(daysPresent, m1, m2, c1, c2);
    }

    public static void print(int[] daysPresent, Manager m1, Manager m2, Clerk c1, Clerk c2) {
    } **/
}
public static void print(Employee[] arr, int[] daysPresent) {
    System.out.printf("%4s", "Employee ID " + " Present " + " Absent " + " Deductions ");
    System.out.println();

    double totDeductions = 0;

    for (int i = 0; i < arr.length; i++) {
        System.out.println(arr[i].getEmployeeID() + "         " + daysPresent[i] + "       " + (20 - daysPresent[i]) +
                "       $" + arr[i].calcDeductions(daysPresent[i]));
        totDeductions += arr[i].calcDeductions(daysPresent[i]);
    }
    System.out.println();
    System.out.println("Total Deductions: " + totDeductions);
}
}
