import java.io.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Input file name: ");
        String inputFileName = keyboard.nextLine();

        File inputFile = new File(inputFileName);
        if (!inputFile.exists()) {
            System.out.println("File does not exist.");
            System.exit(0);
        }

        String tempFileName = "temp.txt";
        File tempFile = new File(tempFileName); //creates temporary file
        if (!tempFile.exists()) {
            try {
                tempFile.createNewFile();
                System.out.println("File created " + tempFileName);
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }

        try {
            Scanner scan = new Scanner(inputFile);
            FileWriter fw = new FileWriter(tempFile);
            PrintWriter pw = new PrintWriter(new FileOutputStream(inputFile, true));

            while (scan.hasNextLine()) {
                String line = scan.nextLine();
                String[] sentences = line.split("\\.");
                for (int i = 0; i < sentences.length; i++) {
                    String sentence = sentences[i];
                    fw.write(sentence.trim() + "\n"); //writes it down to temporary file
                    fw.write(".");
                    pw.write(sentence.trim() + "\n"); //writes it back to source file
                    pw.write(".");
                    pw.println();
                }
            }
            tempFile.delete(); //deletes temporary file
            scan.close();
            fw.close();
            pw.close();
        }
        catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
            System.exit(0);
        }
    }
}
