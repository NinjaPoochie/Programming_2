public class Vehicle {
    private double tankSize;
    private double efficiency;
    private double fuelInTank;

    public Vehicle(double tankSize, double efficiency, double fuelInTank) {
        this.tankSize = tankSize;
        this.efficiency = efficiency;
        this.fuelInTank = fuelInTank;
    }

    //Getters
    public double getTankSize() {
        return tankSize;
    }
    public double getEfficiency() {
        return efficiency;
    }
    public double getFuelInTank() {
        return fuelInTank;
    }

    //Setters
    public void setTankSize(double tankSize) {
        this.tankSize = tankSize;
    }
    public void setEfficiency(double efficiency) {
        this.efficiency = efficiency;
    }
    public void setFuelInTank(double fuelInTank) {
        this.fuelInTank = fuelInTank;
    }

    //Methods
    public double availableTankCapacity() {
        double availableCapacity = tankSize - fuelInTank;
        return availableCapacity;
    }

    public String toString() {
        return "Fuel in tank = " + fuelInTank + "\nTotal Capacity of Tank = " + tankSize + "\nFuel Efficiency = " +
                efficiency + "\nAvailable Capacity of Tank = " + availableTankCapacity();
    }
}
