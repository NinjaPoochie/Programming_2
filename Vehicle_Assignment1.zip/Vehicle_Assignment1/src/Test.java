import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);

        double tankSize;
        double efficiency;
        double fuelInTank = 0;
        double gallons;

        System.out.println("Enter tank size of your car: ");
        tankSize = keyboard.nextDouble();
        System.out.println("Enter the efficiency of the car: ");
        efficiency = keyboard.nextDouble();

        Vehicle aVehicle = new Vehicle(tankSize, efficiency, fuelInTank);
        System.out.println(aVehicle);

        System.out.println("How many gallons of Petrol to add? ");
        gallons = keyboard.nextDouble();

        System.out.println(addPetrol(aVehicle, gallons));
        System.out.println("You can travel " + driveTo(aVehicle, gallons, efficiency) + " miles with available fuel.");
    }

    public static String addPetrol(Vehicle aVehicle, double gallons) {
        if (gallons > aVehicle.availableTankCapacity()) {
            return "Error. Cannot fill tank.";
        } else {
            return "Adding " + gallons + " gallons of fuel to the tank.\nFuel in Tank: " +
                    (aVehicle.getFuelInTank() + gallons) + " gallons";
        }
    }
    public static double driveTo(Vehicle aVehicle, double efficiency, double gallons) {
        return efficiency * (gallons + aVehicle.getFuelInTank());
    }
}
