import java.time.Month;

public class MonthException extends Exception {
    public MonthException() {
        super("Invalid Month");
    }
    public MonthException(String msg) {
        super(msg);
    }
}
