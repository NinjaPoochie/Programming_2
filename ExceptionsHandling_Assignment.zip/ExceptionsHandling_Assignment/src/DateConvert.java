import java.util.InputMismatchException;
import java.util.Scanner;
import java.text.NumberFormat;
import java.util.Date;
import java.util.StringTokenizer;

public class DateConvert {
    public static int maxDay (int monthNum) {
        if (monthNum == 2) {
            return 28;
        } else if (monthNum == 4 || monthNum == 6 || monthNum == 9 || monthNum == 11) {
            return 30;
        } else {
            return 31;
        }
    }

    public static int monthNum(int month) throws MonthException {
        try {
            if (month <= 0 || month > 12) {
                throw new MonthException();
            }
        }
        catch (InputMismatchException e) {
            throw new MonthException();
        }
        return month;
    }

    public static int dayNum(int month, int day) throws DayException {
        try {
            if (month != 2 && (day <= 0 || day > maxDay(month))) {
                throw new DayException();
            }
        }
        catch (InputMismatchException e) {
            throw new DayException();
        }
        return day;
    }

    public static int yearNum(int year) throws YearException {
        try {
            if (year <= 1000 || year > 3000) {
                throw new YearException();
            }
        }
        catch (InputMismatchException e) {
            throw new YearException();
        }
        return year;
    }
    public static int checkFeb(int day, int year) throws DayException {
        int maxDay = maxDay(2);
        if (year % 4 == 0) {
            maxDay++;
        }
        if (day <= 0 || day > maxDay) {
            throw new DayException();
        } else {
            return day;
        }
    }
    public static String monthString(int monthNum) {
        switch(monthNum) {
            case 1:
                return "January";
            case 2:
                return "February";
            case 3:
                return "March";
            case 4:
                return "April";
            case 5:
                return "May";
            case 6:
                return "June";
            case 7:
                return "July";
            case 8:
                return "August";
            case 9:
                return "September";
            case 10:
                return "October";
            case 11:
                return "November";
            case 12:
                return "December";
            default:
                return "Error";
        }
    }

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        DateConvert date = new DateConvert();

        int day = 1;
        int month = 1;
        int year = 1000;

        System.out.println("Enter date to parse (MM/DD/YYYY format): ");
        String userDate = keyboard.nextLine();
        String tokenDate[] = userDate.split("/");

        try { //Puts date into variables
            month = Integer.parseInt(tokenDate[0]);
            day = Integer.parseInt(tokenDate[1]);
            year = Integer.parseInt(tokenDate[2]);
        }
        catch (NumberFormatException n) {
            n.printStackTrace();
        }
        boolean gotMonth = false;
        while (!gotMonth) {
            Scanner userMonth = new Scanner(System.in);
            try {
                month = monthNum(month);
                gotMonth = true;
            }
            catch (MonthException e) {
                System.out.println(e.getMessage());
                System.out.println("Please reenter a valid month: ");
                month = userMonth.nextInt();

            }
        }
        boolean gotDay = false;
        while(!gotDay) {
            Scanner userDay = new Scanner(System.in);
            try {
                day = dayNum(month, day);
                gotDay = true;
            }
            catch (DayException e) {
                System.out.println(e.getMessage());
                System.out.println("Please reenter a valid day: ");
                day = userDay.nextInt();
            }
        }
        boolean gotYear = false;
        while(!gotYear) {
            Scanner userYear = new Scanner(System.in);
            try {
                year = yearNum(year);
                gotYear = true;
            }
            catch (YearException e) {
                System.out.println(e.getMessage());
                System.out.println("Please reenter a valid year: ");
                year = userYear.nextInt();
            }
        }
        if (month ==2) {
            boolean okFebDate = false;
            while(!okFebDate) {
                Scanner userFebDate = new Scanner(System.in);
                try {
                    day = checkFeb(day, year);
                    okFebDate = true;
                }
                catch (DayException e) {
                    System.out.println(e.getMessage());
                    //System.out.println(e1.getMessage());
                    System.out.println("Please reenter a valid day: ");
                    day = userFebDate.nextInt();
                }
            }
        }
        System.out.println("Parsed date: " + monthString(month) + " " + day + ", " + year);
    }
}
