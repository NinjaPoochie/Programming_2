public class YearException extends Exception {
    public YearException() {
        super("Invalid Year");
    }
    public YearException(String msg) {
        super(msg);
    }
}
