import java.util.Scanner;
public class Multidimensional_Arrays {
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);

        char[][] seatChart = new char[7][4];

        for (int i = 0; i < seatChart.length; i++) {
            seatChart[i][0] = 'A';
            seatChart[i][1] = 'B';
            seatChart[i][2] = 'C';
            seatChart[i][3] = 'D';
        }

        String seatNum = "";
        int count = 0;
        int takenSeats = 0;

        System.out.println("You will be selecting seats for this airplane.");
        printArray(seatChart);
        System.out.println("Please enter the seat (ex - 3B) or press Q to quit.");

        seatNum = keyboard.nextLine();
        count++;

        if (seatNum.equals("q")) {
            System.out.println("Program ended.");
            System.exit(0);
        } else {
            while ((takenSeats < 28) && (seatNum.length() > 0)) {
                int row = seatNum.charAt(0) - '1';
                int column = seatNum.charAt(1) - 'A';
                count++;
                if ((row < 0) || (row > 7) || (column < 0) || (column > 4)) {
                    System.out.println("Error. Enter seat to assign (ex - 3B) or Q to quit.");
                    seatNum = keyboard.nextLine();
                    count++;
                }
                if (seatChart[row][column] != 'X') {
                    seatChart[row][column] = 'X';
                    takenSeats++;
                    printArray(seatChart);
                }
                if (takenSeats < 28) {
                    System.out.println("Enter seat to assign (ex - 3B) of Q to quit.");
                    seatNum = keyboard.nextLine();
                    count++;
                }
            }
        }
    }
        private static void printArray(char[][] seats) {
            for (int i = 0; i < seats.length; i++) {
                System.out.println((i + 1) + " " + seats[i][0] + " " + seats[i][1] + " " + seats[i][2] + " " + seats[i][3]);
        }
    }
}
