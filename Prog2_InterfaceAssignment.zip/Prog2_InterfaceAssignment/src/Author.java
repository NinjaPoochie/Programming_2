public class Author implements Comparable<Author> {

    private String firstName, lastName, bookTitle;

    public Author() {
        this("John", "Doe", "No title");
    }
    public Author(String firstName, String lastName, String bookTitle) {
        setFirstName(firstName);
        setLastName(lastName);
        setBookTitle(bookTitle);
    }

    //Setters and Getters
    public String getFirstName() {
        return firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public String getBookTitle() {
        return bookTitle;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    public String toString() {
        return firstName + ", " + lastName + "; " + bookTitle;
    }


     @Override
    public int compareTo(Author a) {
        if (this.lastName.compareTo(a.lastName) != 0) {
            return this.lastName.compareTo(a.lastName);
        } else if (this.lastName.compareTo(a.lastName) == 0) {
            return -1;
        }
         if (this.firstName.compareTo(a.firstName) != 0) {
             return this.firstName.compareTo(a.firstName);
         } else if (this.firstName.compareTo(a.firstName) == 0) {
             return -1;
         }
        if (this.bookTitle.compareTo(a.bookTitle) != 0) {
            return this.bookTitle.compareTo(a.bookTitle);
        }
        return 0;
    }

    /** public int compareTo(Author a) {
        if (this.firstName.compareTo(a.firstName) != 0) {
            return this.firstName.compareTo(a.firstName);
        } else if (this.firstName.compareTo(a.firstName) == 0) {
            if (this.lastName.compareTo(a.lastName) != 0) {
                return this.lastName.compareTo(a.lastName);
            } else if (this.lastName.compareTo(a.lastName) == 0) {
                if (this.bookTitle.compareTo(a.bookTitle) != 0) {
                    return this.bookTitle.compareTo(a.bookTitle);
                }
            }
        }
        return 0;
    } **/
}
