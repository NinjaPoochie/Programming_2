public class Rectangle implements Shape {

    private double height, width;

    public Rectangle() {
        this(0.0, 0.0);
    }
    public Rectangle(double height, double width) {
        setHeight(height);
        setWidth(width);
    }

    //Setters and Getters
    public double getHeight() {
        return height;
    }
    public void setHeight(double height) {
        this.height = height;
    }
    public double getWidth() {
        return width;
    }
    public void setWidth(double width) {
        this.width = width;
    }

    @Override
    public double area() {
        return width * height;
    }
}
