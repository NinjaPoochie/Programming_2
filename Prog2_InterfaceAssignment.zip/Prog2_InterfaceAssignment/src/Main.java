import java.util.ArrayList;
import java.util.Collections;

public class Main {
    public static void main(String[] args) {
        Circle c = new Circle(4);
        Rectangle r = new Rectangle(4,3);

        System.out.println("Task 1");
        System.out.println();

        ShowArea(c);
        ShowArea(r);

        System.out.println();
        System.out.println("Task 2");
        System.out.println();

        Author a1 = new Author("Henry", "Miller", "Tropic of Cancer");
        Author a2 = new Author("Nalo", "Hopkinson", "Brown Girl in the Ring");
        Author a3 = new Author("Frank", "Miller", "300");
        Author a4 = new Author("Deborah", "Hopkinson", "Sky Boys");
        Author a5 = new Author("George R. R.", "Martin", "Song of Ice and Fire");

        ArrayList<Author> list = new ArrayList<>();
        list.add(a1);
        list.add(a2);
        list.add(a3);
        list.add(a4);
        list.add(a5);

        for (Author i:list) {
            System.out.println(i);
        }

        System.out.println();
        System.out.println("***After sorting***");
        System.out.println();

        Collections.sort(list);

        for (Author i:list) {
            System.out.println(i);
        }

    }

    public static void ShowArea(Shape s) {
        double area = s.area();
        System.out.println("The area of the shape is " + area);
    }
}
